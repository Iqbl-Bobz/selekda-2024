// Toggle class active
const navbar = document.querySelector(nav)

//ketika hamburger diklik
document.querySelector('#hamburger-menu').onclick = () =>{
    navbar.classList.toggle('active'); 
};

